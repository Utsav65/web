/**
 * products.js
 *
 * The store's products are defined as an Array of product Objects.
 * Each product Object includes the following properties:
 *
 *  - id: String, a unique product identifier (e.g., "P1", "P2")
 *  - title: String, a short name for the product (e.g., "Gingerbread Cookie")
 *  - description: String, a description of the product
 *  - price: Number, the unit price of the item in whole cents (e.g., 100 = $1.00, 5379 = $53.79)
 *  - discontinued: Boolean, whether or not the product has been discontinued
 *  - categories: Array, the category id or ids to which this product belongs (e.g., ["c1"] or ["c1", "c2"])
 */

window.products = [
  //////////////////////////////Rose//////////////////////////////
  {
    id: "P1",
    title: "Lamborghini",
    imageUrl:
      "https://www.resizepixel.com/Image/9b7c7bmmdf/Preview/sian_05_m.png?v=e42d1157-d648-48f4-8435-75ea6293515d",
    description: `The Lamborghini car has the reputation of being one of the fastest cars to grace the motor racing world, with the Aventador achieving the Lamborghini top speed of 349 kmph. Lamborghini India imports the cars and sells them off the shelf. `,
    price: "256986",
    discontinued: false,
    categories: ["c1"]
  },
  {
    id: "P2",
    title: "lamborghini aventador",
    imageUrl:
      "https://www.resizepixel.com/Image/0qtmd8z7qo/Preview/Lamborghini-Aventador-SVJ-Roadst.png?v=4f711f46-c01c-4ee5-9721-388e60fc7500",
    description: `The Aventador powertrain features a mid-mounted naturally aspirated 6.5-liter V-12 that develops 769 horsepower. The engine's 531 pound-feet of torque makes its way to all four wheels via a seven-speed automated-manual transmission.`,
    price: "464009",
    discontinued: false,
    categories: ["c1"]
  },
  {
    id: "P3",
    title: "lamborghini huracan",
    imageUrl:
      "https://www.resizepixel.com/Image/nlm1o12wot/Preview/2022-Lamborghini-Huracan-STO-PVO.png?v=5cb36e22-4a5a-4bb8-9e48-45526c00228d",
    description: `A naturally aspirated 5.2-liter V-10 is nestled behind the Huracán's cabin, and it exudes a devilish sound whenever it revs towards its 8500-rpm redline. The engine develops 602 horsepower on most rear-drive models, but the rear-drive-only Tecnica and the all-wheel-drive STO have 631 horses.`,
    price: "245245",
    discontinued: false,
    categories: ["c1"]
  },
  {
    id: "P4",
    title: "lamborghini urus",
    imageUrl:
      "https://www.resizepixel.com/Image/vbbq4ihisv/Preview/corpo1_m.png?v=8cbd6686-5e4c-4588-b3ff-c655d91655a2",
    description: `Lamborghini Urus is the first Super Sport Utility Vehicle in the world to merge the soul of a super sports car with the functionality of an SUV. Powered by a 4.0-liter twin-turbo V8 engine producing 650 CV and 850 Nm of torque, Urus accelerates from 0 to 62 mph in 3.6 seconds and reaches a top speed of 190 mph.`,
    price: "256986",
    discontinued: false,
    categories: ["c1"]
  },

  //////////////////////////////Ferrari//////////////////////////////
  {
    id: "P6",
    title: "Ferrari",
    imageUrl:
      "https://www.resizepixel.com/Image/77dsl21icf/Preview/01_Ferrari_SF90_03.png?v=6dc15e32-d4dd-4c67-a596-a429d7874570",
    description: `Ferrari has traded the naturally breathing V-8 for one that is aided by a turbocharger. The change comes for two reasons: it produces less carbon dioxide, and it allows for even more power out of the V-8 without having to make it physically bigger.`,
    price: "264670",
    discontinued: false,
    categories: ["c2"]
  },
  {
    id: "P7",
    title: "Ferrari 812 Superfast",
    imageUrl:
      "https://www.resizepixel.com/Image/5w98d60wvz/Preview/vsavov_170307_1510_0001.0.jpg?v=c2caf5e9-ec88-48f6-8d27-466f2bad62ef",
    description: `Ferrari claims that the 812 Superfast has a top speed of 340 km/h (211 mph) with a 0–100 km/h (0–62 mph) acceleration time of 2.9 seconds. The car has a power to weight ratio of 2.18 kg (4.81 lb) per horsepower (PS). The 812 Superfast is the first Ferrari equipped with EPS (Electronic Power Steering).`,
    price: "452523",
    discontinued: true,
    categories: ["c2"]
  },
  {
    id: "P8",
    title: "Ferrari 812 GTS",
    imageUrl:
      "https://www.resizepixel.com/Image/hzyyqdmipo/Preview/Ferrari-812-GTS.png?v=ae1f9bc5-5efe-4b46-8f08-50805e838639",
    description: `The Ferrari 812 GTS gets its muscle from a 789-hp 6.5-liter V-12, which delivers a bracing 530 pound-feet of torque to the rear wheels via a seven-speed dual-clutch automatic`,
    price: "469318",
    discontinued: false,
    categories: ["c2"]
  },
  {
    id: "P9",
    title: "Ferrari F8 Tributo",
    imageUrl:
      "https://www.resizepixel.com/Image/zr28uk2lnz/Preview/2020-ferrari-f8-tributo-101-1568.jpg?v=efc54602-328e-4ef1-8574-62a15f09547a",
    description: `The Ferrari F8 Tributo is the new mid-rear-engined sports car that represents the highest expression of the Prancing Horse's classic two-seater berlinetta. `,
    price: "322562",
    discontinued: false,
    categories: ["c2"]
  },

  //////////////////////////////Begatti//////////////////////////////
  {
    id: "P11",
    title: "Bugatti",
    imageUrl:
      "https://www.resizepixel.com/Image/2gkchaexdj/Preview/se-image-ce40627babaa7b180bc3ded.jpg?v=596d6d3b-fe89-4a9c-91bf-b62674f89003",
    description: `The Bugatti Veyron EB 16.4 is a mid-engine sports car, designed and developed in France by the Volkswagen Group and Bugatti and manufactured in Molsheim, France, by French automobile manufacturer Bugatti. It was named after the racing driver Pierre Veyron.`,
    price: "1914000",
    discontinued: false,
    categories: ["c3"]
  },
  {
    id: "P12",
    title: "Bugatti Vision",
    imageUrl:
      "https://www.resizepixel.com/Image/ue1d54m83a/Preview/Bugatti_Divo%2c_GIMS_2019%2c_Le_Gran.jpg?v=ceb6e210-15de-4fcf-b8f8-676a31fbf416",
    description: `All Chiron models are motivated by an 8.0-liter 16-cylinder powerplant. This beast of an engine employs four turbochargers to generate a mighty 1500 horsepower and 1180 pound-feet of torque. Bugatti claims that the Chiron makes the dash from zero to 60 mph in a mere 2.3 seconds, and it has a top speed of 261 mph.`,
    price: "18000000",
    discontinued: false,
    categories: ["c3"]
  },
  {
    id: "P13",
    title: "Bugatti Bolide",
    imageUrl:
      "https://www.resizepixel.com/Image/iqmml3u1i8/Preview/bugatti-bolide.jpg?v=51ec5649-f7e4-4651-981b-56ed3e69658a",
    description: `Bolide could hit 100 km/h (62 mph) in 2.17 seconds, 200 km/h (124 mph) in 4.36 seconds, 300 km/h (186 mph) in 7.37 seconds, 248 mph (400 km/h) in 12.08 seconds, and 310 mph (500 km/h) in 20.16 seconds.`,
    price: "5900000 ",
    discontinued: false,
    categories: ["c3"]
  },
  {
    id: "P14",
    title: "Bugatti Centodieci",
    imageUrl:
      "https://www.resizepixel.com/Image/33jsmaxst8/Preview/csm_Stage_Desktop_1920x1280_f2ac.png?v=6c05bef5-97b6-475e-a090-a25aeec4268f",
    description: `the engine is tuned to deliver 1,577 hp, or 97 hp more than the Chiron, and Bugatti claims the car will accelerate from 0-62 mph in 2.4 seconds, from 0-124 mph in 6.1 seconds, and from 0-186 mph in 13.1 seconds. The top speed is governed to 236 mph.`,
    price: "11700000",
    discontinued: true,
    categories: ["c3"]
  }
];
