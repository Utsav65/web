/**
 * WEB222 – Assignment 04
 *
 * I declare that this assignment is my own work in accordance with
 * Seneca Academic Policy. No part of this assignment has been
 * copied manually or electronically from any other source
 * (including web sites) or distributed to other students.
 *
 * Please update the following with your information:
 *
 *      Name:       Utsav Patel
 *      Student ID: 156587206
 *      Date:       21/07/2022
 */

// All of our data is available on the global `window` object.
// Create local variables to work with it in this file.
const { products, categories } = window;
const displayItems = document.querySelector(".display-items");
const navbar = document.querySelector("#menu");

window.addEventListener("DOMContentLoaded", function () {
  document.getElementById("selected-category").textContent = "Lamborghini";
  displayProductItems(
    products.filter(function (product) {
      if (product.categories.includes("c1")) {
        return product;
      }
    })
  );

  displayMenuButtons();
});

function displayProductItems(productItems) {
  let displayProducts = productItems.map(function (product) {
    return createProductCard(product);
  });

  displayProducts = displayProducts.join("");
  displayItems.innerHTML = displayProducts;
}

function createProductCard(product) {
  return `<article class="card">
      <img src="${product.imageUrl}" alt="Product-Image">
      <div class="card-info">
      <header>
        <h4>${product.title}</h4>
        <h4 class="price">CAD${(product.price / 1).toLocaleString("en-CA", {
          currency: "CAD",
          style: "currency"
        })}</h4>
      </header>
      <p class="card-text">${product.description}</p>
      </div>
    </article>`;
}

function displayMenuButtons() {
  // Creating the navbar dynamically
  const cats = categories
    .map(function (item) {
      return `<button data-id="${item.name}" class="filter-btn" type="button">${item.name}</button>`;
    })
    .join("");

  navbar.innerHTML = cats;
  const filterBtns = document.querySelectorAll(".filter-btn");

  filterBtns.forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      let category = e.currentTarget.dataset.id;
      document.getElementById("selected-category").textContent = e.currentTarget.dataset.id;

      // Converting human readable to category codes
      if (category === "Lamborghini") {
        category = "c1";
      } else if (category === "Ferrari") {
        category = "c2";
      } else if (category === "Bugatti") {
        category = "c3";
      }
      const productCategory = products.filter(function (item) {
        if (item.categories.includes(category)) {
          return item;
        }
      });

      displayProductItems(productCategory);
    });
  });
}
